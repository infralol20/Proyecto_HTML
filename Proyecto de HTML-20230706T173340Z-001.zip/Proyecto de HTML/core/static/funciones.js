function showRegistro(sw){
    var login = document.querySelector("#login");
    var regis = document.querySelector("#registro");
    login.classList.add(sw?"hide":"showLogin");
    regis.classList.add(sw?"show":"hide");
    login.classList.remove(!sw?"hide":"showLogin");
    regis.classList.remove(!sw?"show":"hide");
    return false;
}
const botonesCompra = document.querySelectorAll('.comprar-btn');
    botonesCompra.forEach(boton => {
      boton.addEventListener('click', event => {
        const confirmacion = confirm('¿Confirmar compra?');
        if (!confirmacion) {
          event.preventDefault(); 
        }
      });
    })