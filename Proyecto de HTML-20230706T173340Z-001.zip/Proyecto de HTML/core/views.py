from django.shortcuts import render, redirect
from .models import Producto, Compra, HistorialCompra
from django.contrib.auth.views import logout_then_login
from .forms import *
from django.contrib import messages


def registro(request):
    if request.method == "POST":
        form = Registro(request.POST)
        if form.is_valid():
            form.save()
            return redirect("login")
    else:        
        form = Registro()
    return render(request, 'core/registro.html', {'form':form})

def home(request):
    plantas = Producto.objects.all()
    return render(request, 'core/index.html', {'plantas':plantas})

def quienes(request):
    return render(request, 'core/quienes.html')

def logout(request):
    return logout_then_login(request, login_url="login")

def limpiar(request):
    request.session.flush()
    plantas = Producto.objects.all()
    return render(request, 'core/index.html', {'plantas':plantas})

def addtocar(request, codigo):
    producto = Producto.objects.get(codigo=codigo)
    carro = request.session.get("carro", [])
    for c in carro:
        if c[0] == codigo:
            c[2] = c[2] + 1
            c[5] = c[2] * c[1]
            break
    else:
        carro.append([codigo, producto.precio, 1, producto.imagen, producto.descripcion, producto.precio])
    
    request.session["carro"] = carro
    plantas = Producto.objects.all()
    return render(request, 'core/index.html', {'plantas':plantas})

def carrito(request):
    carro = request.session.get("carro", [])
    return render(request, 'core/carrito.html', {"carro":carro})

def droptocar(request, codigo):
    carro = request.session.get("carro", [])
    for c in carro:
        if c[0] == codigo:
            carro.remove(c)
            break
    request.session["carro"] = carro
    return render(request, 'core/carrito.html', {"carro":carro})
def comprar(request):
    carro=request.session.get("carro",[])
    total= 0 
    for c in carro:
        total+= c[5]
    venta=Venta()
    venta.cliente= request.user
    venta.total= total
    venta.save()
    for c in carro:
        producto=Producto.object.get(codigo=c[0])
        detalle=Detalle()
        detalle.venta=venta
        detalle.producto=producto
        detalle.cantidad=c[2]
        detalle.precio=c[1]
        detalle.total= c[5]
        detalle.save()
        producto.stock=producto.stock - c[2]
        producto.saveI()
    request.session["carro"]= []
    return redirect()



def compra(request):
    if request.method == 'POST':
        producto_id = request.POST.get('producto_id')
        cantidad = int(request.POST.get('cantidad'))

        producto = Producto.objects.get(pk=producto_id)

        if producto.stock >= cantidad:
            # Registrar la compra
            compra = Compra(usuario=request.user, producto=producto, cantidad=cantidad, precio=producto.precio * cantidad)
            compra.save()

            # Descontar el stock
            producto.stock -= cantidad
            producto.save()

            # Registrar en el historial de compra
            historial_compra = HistorialCompra(usuario=request.user, producto=producto, cantidad=cantidad, precio=producto.precio * cantidad)
            historial_compra.save()

            return redirect('compra')  # Redireccionar a la misma página después de realizar la compra
        else:
            error_message = 'No hay suficiente stock disponible.'
            productos = Producto.objects.all()
            return render(request, 'compra.html', {'productos': productos, 'error_message': error_message})
    else:
        productos = Producto.objects.all()
        return render(request, 'compra.html', {'productos':productos})


def historia_compra(request):
    historial = HistorialCompra.objects.filter(usuario=request.user)
    return render(request, 'procesar_compra.html')

