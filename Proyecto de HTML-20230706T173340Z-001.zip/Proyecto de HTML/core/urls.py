from django.urls import path
from .views import *
from django.contrib.auth.views import LoginView
from . import views

urlpatterns = [
    path("", home, name="home"),    
    path("login", LoginView.as_view(template_name="core/login.html"), name="login"),    
    path("logout", logout, name="logout"),
    path("quienes", quienes, name="quienes"),    
    path("registro", registro, name="registro"),
    path("home/<codigo>", addtocar, name="addtocar"),
    path("droptocar/<codigo>", droptocar, name="droptocar"),
    path("limpiar", limpiar, name="limpiar"),
    path("carrito", carrito, name="carrito"),
    path('compra/', views.compra, name='compra'),
    path('historia_compra/', views.historia_compra, name='historia_compra'),


]
